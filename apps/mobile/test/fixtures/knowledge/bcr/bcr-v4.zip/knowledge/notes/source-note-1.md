---
bcr: 2
id: source-note-1
title: 资产配置
path: 投资/资产配置.md
tags:
  - 投资
  - 配置
collectionId: research
createdAt: 1735689600000
updatedAt: 1735776000000
---
# 资产配置

权益仓位上限为 60%。

[证据](attachment:asset-one)
